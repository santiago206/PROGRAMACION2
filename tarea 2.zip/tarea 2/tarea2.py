from flask import Flask
from flask import render_template

app = Flask(__name__)

@app.route('/')
def html():
    return render_template('main.html')

@app.route('/index.html')
def index():
    return render_template('index.html')


@app.route('/mision.html')
def mision():
    return render_template('mision.html')

@app.route('/vision.html')
def vision():
    return render_template('vision.html')

@app.route('/contacto.html')
def contacto():
    return render_template('contacto.html')